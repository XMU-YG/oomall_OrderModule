package cn.edu.xmu.order_provider.model.order;


import lombok.Data;


import java.io.Serializable;
import java.util.List;

@Data
public class OrderVo implements Serializable {

    private List<OrderItemVo> orderItems;

    private String consignee;

    private Long regionId;

    private String address;

    private String mobile;

    private String message;

    private Long couponId;

    private Long presaleId;

    private Long grouponId;

}
